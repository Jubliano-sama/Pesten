"""Native PufferLib 4 MinGRU policy for information-safe Pesten inputs.

This module intentionally imports the pinned v4 API and therefore belongs in
the isolated ``puffer4-native`` runtime.  The separate fallback implementation
in ``temporal_puffer_agent.py`` remains usable by the legacy environment.
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Mapping

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

import pufferlib
import pufferlib.models

from temporal_observation import (
    DecisionInput,
    EVENT_TOKEN_SIZE,
    OBSERVATION_SIZE,
)
from temporal_puffer_agent import PolicyStep


PUFFERLIB_REVISION = "c5d3c637446047a6efbcaa74c039c5295d201ab0"
NATIVE_INPUT_SIZE = OBSERVATION_SIZE + EVENT_TOKEN_SIZE + 1
FLAT_ACTION_HEAD = "flat_55"
MODE_CONDITIONED_ACTION_HEAD = "mode_conditioned_55"
FACTORIZED_ACTION_HEAD = "factorized_23"
FACTORIZED_SCORE_COUNT = 23


def require_pufferlib_v4() -> None:
    version = str(getattr(pufferlib, "__version__", ""))
    if not version.startswith("4"):
        raise RuntimeError(
            f"native temporal policy requires PufferLib 4, found {version!r}"
        )


class NativePufferTemporalPolicy(nn.Module):
    """Real ``Policy`` + ``MinGRU`` v4 model behind the safe schema boundary."""

    native_pufferlib = True
    pufferlib_revision = PUFFERLIB_REVISION
    integration_status = (
        "Native PufferLib 4.0 Policy/MinGRU at "
        f"{PUFFERLIB_REVISION}"
    )

    def __init__(
        self,
        hidden_size: int = 96,
        num_layers: int = 1,
        *,
        mode_conditioned_heads: bool = False,
        action_head: str | None = None,
    ) -> None:
        super().__init__()
        require_pufferlib_v4()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.mode_conditioned_heads = mode_conditioned_heads
        self.action_head = action_head or (
            MODE_CONDITIONED_ACTION_HEAD
            if mode_conditioned_heads
            else FLAT_ACTION_HEAD
        )
        encoder = pufferlib.models.DefaultEncoder(
            NATIVE_INPUT_SIZE, hidden_size
        )
        decoder = build_action_decoder(
            hidden_size,
            mode_conditioned_heads=mode_conditioned_heads,
            action_head=self.action_head,
        )
        network = pufferlib.models.MinGRU(
            hidden_size=hidden_size, num_layers=num_layers
        )
        self.puffer_policy = pufferlib.models.Policy(
            encoder, decoder, network
        )

    def initial_state(
        self,
        batch_size: int = 1,
        *,
        device: torch.device | str | None = None,
    ) -> tuple[torch.Tensor, ...]:
        resolved_device = device or getattr(
            self, "_rollout_device", None
        )
        if resolved_device is None:
            resolved_device = next(self.parameters()).device
        return self.puffer_policy.initial_state(
            batch_size, resolved_device
        )

    @staticmethod
    def _event_values(event) -> tuple[float, ...]:
        return (
            int(event.kind) / 3.0,
            event.actor_relative / 12.0,
            (event.card_id + 1) / 50.0,
            (event.suit_id + 1) / 5.0,
            event.count / 54.0,
        )

    @staticmethod
    def _event_features_from_events(events) -> list[tuple[float, ...]]:
        prefix = (0.0,) * OBSERVATION_SIZE
        return [
            prefix + NativePufferTemporalPolicy._event_values(event) + (0.0,)
            for event in events
        ]

    @staticmethod
    def _event_features(decision: DecisionInput) -> list[tuple[float, ...]]:
        return NativePufferTemporalPolicy._event_features_from_events(
            decision.public_events
        )

    @staticmethod
    def _event_tokens_from_events(
        events,
        *,
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        """Materialize sparse event features without 94 Python zeros each."""
        tokens = np.zeros((len(events), NATIVE_INPUT_SIZE), dtype=np.float32)
        if len(events):
            tokens[:, OBSERVATION_SIZE:-1] = [
                NativePufferTemporalPolicy._event_values(event) for event in events
            ]
        return torch.from_numpy(tokens).to(device=device, dtype=dtype)

    @staticmethod
    def _decision_features(decision: DecisionInput) -> tuple[float, ...]:
        return (
            decision.observation.values
            + (0.0,) * EVENT_TOKEN_SIZE
            + (1.0,)
        )

    def step(
        self,
        decision: DecisionInput,
        state: tuple[torch.Tensor, ...],
    ) -> PolicyStep:
        """Advance native MinGRU over public events, then the private decision."""
        if not isinstance(decision, DecisionInput):
            raise TypeError("native policy accepts only DecisionInput")
        parameter = next(self.parameters())
        device, dtype = parameter.device, parameter.dtype
        next_state = state
        event_rows = self._event_features(decision)
        if event_rows:
            event_tokens = torch.tensor(
                event_rows,
                device=device,
                dtype=dtype,
            )
            for token in event_tokens:
                _, _, next_state = self.puffer_policy.forward_eval(
                    token.unsqueeze(0), next_state
                )

        token = torch.tensor(
            self._decision_features(decision),
            device=device,
            dtype=dtype,
        ).unsqueeze(0)
        logits, values, next_state = self.puffer_policy.forward_eval(
            token, next_state
        )
        legal = torch.tensor(
            decision.legal_actions, device=device, dtype=torch.bool
        ).unsqueeze(0)
        masked_logits = logits.masked_fill(
            ~legal, torch.finfo(logits.dtype).min
        )
        return PolicyStep(
            logits=masked_logits.squeeze(0),
            value=values.reshape(-1)[0],
            state=next_state,
        )

    def forward_native_sequence(
        self, safe_tokens: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Expose the genuine v4 batched training path for safe token tensors."""
        if safe_tokens.ndim != 3 or safe_tokens.shape[-1] != NATIVE_INPUT_SIZE:
            raise ValueError(
                "safe_tokens must have shape [batch, time, "
                f"{NATIVE_INPUT_SIZE}]"
            )
        return self.puffer_policy(safe_tokens)

    def model_config(self) -> dict[str, object]:
        return {
            "architecture": "min_gru",
            "hidden_size": self.hidden_size,
            "num_layers": self.num_layers,
            "mode_conditioned_heads": self.mode_conditioned_heads,
            "action_head": self.action_head,
        }


class ModeConditionedDecoder(nn.Module):
    """Separate card/pass and four-way suit heads in the 55-action contract."""

    nvec = (55,)
    is_continuous = False

    def __init__(self, hidden_size: int) -> None:
        super().__init__()
        self.card_and_pass = nn.Linear(hidden_size, 51)
        self.suit = nn.Linear(hidden_size, 4)
        self.value_function = nn.Linear(hidden_size, 1)

    def forward(
        self, hidden: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        card_and_pass = self.card_and_pass(hidden)
        logits = torch.cat(
            (
                card_and_pass[..., :50],
                self.suit(hidden),
                card_and_pass[..., 50:51],
            ),
            dim=-1,
        )
        return logits, self.value_function(hidden)


class FactorizedActionDecoder(nn.Module):
    """Twenty-three learned scores expanded into 55 concrete actions.

    The learned output contract is:

    * 0-3: playing-card suit scores (harten, ruiten, schoppen, klaveren)
    * 4-15: ordinary rank scores (ace, 2 through 10, king, queen)
    * 16: jack/boer score
    * 17: joker score
    * 18: pass score
    * 19-22: announced-suit scores after a jack

    An ordinary card logit is its suit score plus its rank score. The fixed
    expansion preserves the environment's established 55-action API while
    reducing the learned policy output from 55 arbitrary logits to 23 scores.
    """

    nvec = (55,)
    is_continuous = False
    score_count = FACTORIZED_SCORE_COUNT

    def __init__(self, hidden_size: int) -> None:
        super().__init__()
        self.scores = nn.Linear(hidden_size, self.score_count)
        self.value_function = nn.Linear(hidden_size, 1)

    @staticmethod
    def expand_scores(scores: torch.Tensor) -> torch.Tensor:
        if scores.shape[-1] != FACTORIZED_SCORE_COUNT:
            raise ValueError(
                "factorized action scores must have a final dimension of 23"
            )
        ordinary_cards = (
            scores[..., 0:4].unsqueeze(-1)
            + scores[..., 4:16].unsqueeze(-2)
        ).flatten(start_dim=-2)
        return torch.cat(
            (
                ordinary_cards,
                scores[..., 16:18],
                scores[..., 19:23],
                scores[..., 18:19],
            ),
            dim=-1,
        )

    def forward(
        self, hidden: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        scores = self.scores(hidden)
        return self.expand_scores(scores), self.value_function(hidden)


def build_action_decoder(
    hidden_size: int,
    *,
    mode_conditioned_heads: bool,
    action_head: str,
) -> nn.Module:
    if action_head == FACTORIZED_ACTION_HEAD:
        if not mode_conditioned_heads:
            raise ValueError(
                "the factorized 23-score head requires mode-conditioned heads"
            )
        return FactorizedActionDecoder(hidden_size)
    if action_head == MODE_CONDITIONED_ACTION_HEAD:
        if not mode_conditioned_heads:
            raise ValueError(
                "the mode-conditioned action head requires mode-conditioned heads"
            )
        return ModeConditionedDecoder(hidden_size)
    if action_head == FLAT_ACTION_HEAD:
        if mode_conditioned_heads:
            raise ValueError(
                "the flat action head is incompatible with mode-conditioned heads"
            )
        return pufferlib.models.DefaultDecoder((55,), hidden_size)
    raise ValueError(f"unsupported temporal action head: {action_head}")


class RealGatedLinearRecurrentUnit(nn.Module):
    """Hawk-style stable diagonal recurrence with input-dependent forgetting.

    The recurrence follows the RG-LRU design from De et al. (2024): a
    learnable stable diagonal coefficient is modulated by an input gate, and
    the injected value is variance-normalized by ``sqrt(1 - a**2)``.  Its
    state is linear in width, which keeps online inference cheap.
    """

    def __init__(self, width: int) -> None:
        super().__init__()
        if width < 1:
            raise ValueError("RG-LRU width must be positive")
        self.width = width
        self.input_gate = nn.Linear(width, width)
        self.recurrence_gate = nn.Linear(width, width)
        # Spread initial memory constants from roughly 8 to 512 steps.  The
        # paper uses a stable sigmoid parameterization and c=8.
        target = torch.exp(
            -1.0
            / torch.logspace(
                math.log10(8.0), math.log10(512.0), width
            )
        ).clamp(1e-4, 1.0 - 1e-4)
        self.recurrence_logits = nn.Parameter(torch.logit(target))

    def _terms(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        recurrence_gate = torch.sigmoid(self.recurrence_gate(x))
        input_gate = torch.sigmoid(self.input_gate(x))
        log_base = F.logsigmoid(self.recurrence_logits)
        log_a = 8.0 * recurrence_gate * log_base
        a = torch.exp(log_a)
        injected = (
            torch.sqrt(torch.clamp(1.0 - a.square(), min=1e-6))
            * input_gate
            * x
        )
        return a, injected

    @staticmethod
    def _signed_parallel_scan(
        a: torch.Tensor, injected: torch.Tensor
    ) -> torch.Tensor:
        """Evaluate ``h[t] = a[t] h[t-1] + injected[t]`` in parallel.

        Positive coefficients let us use two stable log-cumulative-exp scans
        for the positive and negative injected values.  This avoids a Python
        time loop and remains differentiable on ordinary PyTorch kernels.
        """
        log_a_prefix = torch.log(a).cumsum(dim=1)
        # A finite log-zero keeps backward stable when an entire prefix has
        # no values of one sign.  Identical floors cancel between the two
        # signed scans and are far below float32 policy precision.
        log_zero = math.log(torch.finfo(injected.dtype).tiny)
        negative_infinity = torch.full_like(injected, log_zero)
        positive_mask = injected > 0
        negative_mask = injected < 0
        positive_magnitude = torch.where(
            positive_mask, injected, torch.ones_like(injected)
        )
        negative_magnitude = torch.where(
            negative_mask, -injected, torch.ones_like(injected)
        )
        positive_logs = torch.where(
            positive_mask,
            torch.log(positive_magnitude),
            negative_infinity,
        )
        negative_logs = torch.where(
            negative_mask,
            torch.log(negative_magnitude),
            negative_infinity,
        )
        positive = torch.exp(
            log_a_prefix
            + torch.logcumsumexp(positive_logs - log_a_prefix, dim=1)
        )
        negative = torch.exp(
            log_a_prefix
            + torch.logcumsumexp(negative_logs - log_a_prefix, dim=1)
        )
        return positive - negative

    def forward_train(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim != 3 or x.shape[-1] != self.width:
            raise ValueError("RG-LRU training input must be [batch,time,width]")
        a, injected = self._terms(x)
        return self._signed_parallel_scan(a, injected)

    def forward_eval(
        self, x: torch.Tensor, state: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if x.ndim != 2 or x.shape[-1] != self.width:
            raise ValueError("RG-LRU eval input must be [batch,width]")
        if state.shape != x.shape:
            raise ValueError("RG-LRU state must match the eval input shape")
        a, injected = self._terms(x)
        next_state = a * state + injected
        return next_state, next_state


class HawkRGLRUBlock(nn.Module):
    """Inference-efficient recurrent residual block inspired by Hawk."""

    def __init__(
        self,
        hidden_size: int,
        recurrent_size: int,
        mlp_expansion: int,
    ) -> None:
        super().__init__()
        self.recurrent_norm = nn.RMSNorm(hidden_size)
        self.recurrent_projection = nn.Linear(
            hidden_size, 2 * recurrent_size, bias=False
        )
        self.rg_lru = RealGatedLinearRecurrentUnit(recurrent_size)
        self.recurrent_output = nn.Linear(
            recurrent_size, hidden_size, bias=False
        )
        self.mlp_norm = nn.RMSNorm(hidden_size)
        expanded = hidden_size * mlp_expansion
        self.mlp_projection = nn.Linear(
            hidden_size, 2 * expanded, bias=False
        )
        self.mlp_output = nn.Linear(expanded, hidden_size, bias=False)

    def _recurrent_input(
        self, hidden: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        value, gate = self.recurrent_projection(
            self.recurrent_norm(hidden)
        ).chunk(2, dim=-1)
        return value, F.silu(gate)

    def _mlp(self, hidden: torch.Tensor) -> torch.Tensor:
        gate, value = self.mlp_projection(
            self.mlp_norm(hidden)
        ).chunk(2, dim=-1)
        return self.mlp_output(F.silu(gate) * value)

    def forward_train(self, hidden: torch.Tensor) -> torch.Tensor:
        value, gate = self._recurrent_input(hidden)
        recurrent = self.rg_lru.forward_train(value)
        hidden = hidden + self.recurrent_output(recurrent * gate)
        return hidden + self._mlp(hidden)

    def forward_eval(
        self, hidden: torch.Tensor, state: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        value, gate = self._recurrent_input(hidden)
        recurrent, next_state = self.rg_lru.forward_eval(value, state)
        hidden = hidden + self.recurrent_output(recurrent * gate)
        return hidden + self._mlp(hidden), next_state


class HawkRGLRUNetwork(nn.Module):
    """Stacked Hawk-style blocks behind PufferLib's Policy interface."""

    def __init__(
        self,
        hidden_size: int,
        num_layers: int,
        *,
        recurrent_size: int,
        mlp_expansion: int,
    ) -> None:
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.recurrent_size = recurrent_size
        self.layers = nn.ModuleList(
            HawkRGLRUBlock(
                hidden_size,
                recurrent_size,
                mlp_expansion,
            )
            for _ in range(num_layers)
        )
        self.final_norm = nn.RMSNorm(hidden_size)
        residual_scale = 1.0 / math.sqrt(max(1, 2 * num_layers))
        with torch.no_grad():
            for block in self.layers:
                block.recurrent_output.weight.mul_(residual_scale)
                block.mlp_output.weight.mul_(residual_scale)

    def initial_state(
        self, batch_size: int, device: torch.device | str
    ) -> tuple[torch.Tensor, ...]:
        return (
            torch.zeros(
                self.num_layers,
                batch_size,
                self.recurrent_size,
                device=device,
            ),
        )

    def forward_train(self, hidden: torch.Tensor) -> torch.Tensor:
        for block in self.layers:
            hidden = block.forward_train(hidden)
        return self.final_norm(hidden)

    def forward_eval(
        self,
        hidden: torch.Tensor,
        state: tuple[torch.Tensor, ...],
    ) -> tuple[torch.Tensor, tuple[torch.Tensor, ...]]:
        recurrent_state = state[0]
        if recurrent_state.shape[:2] != (self.num_layers, hidden.shape[0]):
            raise ValueError("Hawk recurrent state shape does not match batch")
        next_rows = []
        for index, block in enumerate(self.layers):
            hidden, next_state = block.forward_eval(
                hidden, recurrent_state[index]
            )
            next_rows.append(next_state)
        return self.final_norm(hidden), (torch.stack(next_rows, dim=0),)


class HawkRGLRUTemporalPolicy(NativePufferTemporalPolicy):
    """Hawk-inspired fixed-state alternative to the Puffer MinGRU policy."""

    integration_status = "Hawk-style RG-LRU policy on PufferLib 4 Policy API"

    def __init__(
        self,
        hidden_size: int = 256,
        num_layers: int = 4,
        *,
        recurrent_size: int | None = None,
        mlp_expansion: int = 2,
        mode_conditioned_heads: bool = True,
    ) -> None:
        nn.Module.__init__(self)
        require_pufferlib_v4()
        if hidden_size < 1 or num_layers < 1 or mlp_expansion < 1:
            raise ValueError("Hawk dimensions must be positive")
        recurrent_size = recurrent_size or math.ceil(4 * hidden_size / 3)
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.recurrent_size = recurrent_size
        self.mlp_expansion = mlp_expansion
        self.mode_conditioned_heads = mode_conditioned_heads
        encoder = pufferlib.models.DefaultEncoder(
            NATIVE_INPUT_SIZE, hidden_size
        )
        decoder = (
            ModeConditionedDecoder(hidden_size)
            if mode_conditioned_heads
            else pufferlib.models.DefaultDecoder((55,), hidden_size)
        )
        network = HawkRGLRUNetwork(
            hidden_size,
            num_layers,
            recurrent_size=recurrent_size,
            mlp_expansion=mlp_expansion,
        )
        self.puffer_policy = pufferlib.models.Policy(
            encoder, decoder, network
        )

    def model_config(self) -> dict[str, object]:
        return {
            "architecture": "hawk_rglru",
            "hidden_size": self.hidden_size,
            "num_layers": self.num_layers,
            "recurrent_size": self.recurrent_size,
            "mlp_expansion": self.mlp_expansion,
            "mode_conditioned_heads": self.mode_conditioned_heads,
        }


class ResidualTemporalPolicyCore(nn.Module):
    """Add a trainable policy branch to a complete recurrent base policy."""

    def __init__(self, base: nn.Module, adapter: nn.Module) -> None:
        super().__init__()
        self.base = base
        self.adapter = adapter
        # Both current PufferLib recurrent networks return one tensor, but keep
        # the split explicit so a future network can expose structured state.
        self.base_state_parts = len(self.base.initial_state(1, "cpu"))
        self.adapter_state_parts = len(self.adapter.initial_state(1, "cpu"))

    def initial_state(
        self, batch_size: int, device: torch.device | str
    ) -> tuple[torch.Tensor, ...]:
        return (
            *self.base.initial_state(batch_size, device),
            *self.adapter.initial_state(batch_size, device),
        )

    def forward(
        self, hidden: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        base_logits, base_values = self.base(hidden)
        adapter_logits, adapter_values = self.adapter(hidden)
        return base_logits + adapter_logits, base_values + adapter_values

    def forward_eval(
        self,
        hidden: torch.Tensor,
        state: tuple[torch.Tensor, ...],
    ) -> tuple[torch.Tensor, torch.Tensor, tuple[torch.Tensor, ...]]:
        expected = self.base_state_parts + self.adapter_state_parts
        if len(state) != expected:
            raise ValueError(
                f"residual policy expects {expected} recurrent-state parts"
            )
        base_state = state[: self.base_state_parts]
        adapter_state = state[self.base_state_parts :]
        base_logits, base_values, next_base = self.base.forward_eval(
            hidden, base_state
        )
        adapter_logits, adapter_values, next_adapter = (
            self.adapter.forward_eval(hidden, adapter_state)
        )
        return (
            base_logits + adapter_logits,
            base_values + adapter_values,
            (*next_base, *next_adapter),
        )


class MinGRUResidualTemporalPolicy(NativePufferTemporalPolicy):
    """Exact MinGRU base plus a wider/deeper residual MinGRU branch."""

    integration_status = (
        "Function-preserving MinGRU plus wider/deeper MinGRU residual policy"
    )

    def __init__(
        self,
        base_hidden_size: int = 192,
        base_num_layers: int = 2,
        *,
        adapter_hidden_size: int = 512,
        adapter_num_layers: int = 6,
        mode_conditioned_heads: bool = True,
        action_head: str | None = None,
    ) -> None:
        nn.Module.__init__(self)
        require_pufferlib_v4()
        dimensions = (
            base_hidden_size,
            base_num_layers,
            adapter_hidden_size,
            adapter_num_layers,
        )
        if any(value < 1 for value in dimensions):
            raise ValueError("residual MinGRU dimensions must be positive")
        self.hidden_size = base_hidden_size
        self.num_layers = base_num_layers
        self.base_hidden_size = base_hidden_size
        self.base_num_layers = base_num_layers
        self.adapter_hidden_size = adapter_hidden_size
        self.adapter_num_layers = adapter_num_layers
        self.mode_conditioned_heads = mode_conditioned_heads
        self.action_head = action_head or (
            MODE_CONDITIONED_ACTION_HEAD
            if mode_conditioned_heads
            else FLAT_ACTION_HEAD
        )

        def branch(width: int, layers: int) -> nn.Module:
            return pufferlib.models.Policy(
                pufferlib.models.DefaultEncoder(NATIVE_INPUT_SIZE, width),
                build_action_decoder(
                    width,
                    mode_conditioned_heads=mode_conditioned_heads,
                    action_head=self.action_head,
                ),
                pufferlib.models.MinGRU(
                    hidden_size=width,
                    num_layers=layers,
                ),
            )

        self.puffer_policy = ResidualTemporalPolicyCore(
            branch(base_hidden_size, base_num_layers),
            branch(adapter_hidden_size, adapter_num_layers),
        )

    def model_config(self) -> dict[str, object]:
        return {
            "architecture": "min_gru_residual",
            "hidden_size": self.base_hidden_size,
            "num_layers": self.base_num_layers,
            "base_hidden_size": self.base_hidden_size,
            "base_num_layers": self.base_num_layers,
            "adapter_hidden_size": self.adapter_hidden_size,
            "adapter_num_layers": self.adapter_num_layers,
            "mode_conditioned_heads": self.mode_conditioned_heads,
            "action_head": self.action_head,
        }


class HawkResidualTemporalPolicy(NativePufferTemporalPolicy):
    """Exact MinGRU teacher plus a zero-output Hawk recurrent adapter.

    This is a Net2Net-style function-preserving student: before RLVR, the
    complete base branch is identical to its teacher and the independently
    initialized Hawk branch contributes exactly zero logits and value.  RLVR
    can then use the adapter's different recurrence without first relearning
    the teacher's policy over the combinatorial game-state distribution.
    """

    integration_status = (
        "Function-preserving MinGRU plus Hawk RG-LRU residual policy"
    )

    def __init__(
        self,
        base_hidden_size: int = 192,
        base_num_layers: int = 2,
        *,
        adapter_hidden_size: int = 128,
        adapter_num_layers: int = 2,
        adapter_recurrent_size: int | None = None,
        adapter_mlp_expansion: int = 2,
        mode_conditioned_heads: bool = True,
    ) -> None:
        nn.Module.__init__(self)
        require_pufferlib_v4()
        dimensions = (
            base_hidden_size,
            base_num_layers,
            adapter_hidden_size,
            adapter_num_layers,
            adapter_mlp_expansion,
        )
        if any(value < 1 for value in dimensions):
            raise ValueError("residual policy dimensions must be positive")
        adapter_recurrent_size = adapter_recurrent_size or math.ceil(
            4 * adapter_hidden_size / 3
        )
        self.hidden_size = base_hidden_size
        self.num_layers = base_num_layers
        self.base_hidden_size = base_hidden_size
        self.base_num_layers = base_num_layers
        self.adapter_hidden_size = adapter_hidden_size
        self.adapter_num_layers = adapter_num_layers
        self.adapter_recurrent_size = adapter_recurrent_size
        self.adapter_mlp_expansion = adapter_mlp_expansion
        self.mode_conditioned_heads = mode_conditioned_heads

        def decoder(width: int) -> nn.Module:
            return (
                ModeConditionedDecoder(width)
                if mode_conditioned_heads
                else pufferlib.models.DefaultDecoder((55,), width)
            )

        base = pufferlib.models.Policy(
            pufferlib.models.DefaultEncoder(
                NATIVE_INPUT_SIZE, base_hidden_size
            ),
            decoder(base_hidden_size),
            pufferlib.models.MinGRU(
                hidden_size=base_hidden_size,
                num_layers=base_num_layers,
            ),
        )
        adapter = pufferlib.models.Policy(
            pufferlib.models.DefaultEncoder(
                NATIVE_INPUT_SIZE, adapter_hidden_size
            ),
            decoder(adapter_hidden_size),
            HawkRGLRUNetwork(
                adapter_hidden_size,
                adapter_num_layers,
                recurrent_size=adapter_recurrent_size,
                mlp_expansion=adapter_mlp_expansion,
            ),
        )
        self.puffer_policy = ResidualTemporalPolicyCore(base, adapter)

    def model_config(self) -> dict[str, object]:
        return {
            "architecture": "hawk_residual",
            "base_hidden_size": self.base_hidden_size,
            "base_num_layers": self.base_num_layers,
            "adapter_hidden_size": self.adapter_hidden_size,
            "adapter_num_layers": self.adapter_num_layers,
            "adapter_recurrent_size": self.adapter_recurrent_size,
            "adapter_mlp_expansion": self.adapter_mlp_expansion,
            "mode_conditioned_heads": self.mode_conditioned_heads,
        }


def build_temporal_policy(model: Mapping[str, object]) -> nn.Module:
    """Construct a supported native safe-temporal policy from metadata."""
    architecture = str(model.get("architecture", "min_gru"))
    common = {
        "hidden_size": int(model.get("hidden_size", 96)),
        "num_layers": int(model.get("num_layers", 1)),
        "mode_conditioned_heads": bool(
            model.get("mode_conditioned_heads", False)
        ),
    }
    if architecture in {"min_gru", "native_min_gru"}:
        return NativePufferTemporalPolicy(
            **common,
            action_head=str(
                model.get(
                    "action_head",
                    MODE_CONDITIONED_ACTION_HEAD
                    if common["mode_conditioned_heads"]
                    else FLAT_ACTION_HEAD,
                )
            ),
        )
    if architecture == "hawk_rglru":
        return HawkRGLRUTemporalPolicy(
            **common,
            recurrent_size=int(
                model.get(
                    "recurrent_size",
                    math.ceil(4 * common["hidden_size"] / 3),
                )
            ),
            mlp_expansion=int(model.get("mlp_expansion", 2)),
        )
    if architecture == "min_gru_residual":
        return MinGRUResidualTemporalPolicy(
            base_hidden_size=int(model.get("base_hidden_size", 192)),
            base_num_layers=int(model.get("base_num_layers", 2)),
            adapter_hidden_size=int(model.get("adapter_hidden_size", 512)),
            adapter_num_layers=int(model.get("adapter_num_layers", 6)),
            mode_conditioned_heads=common["mode_conditioned_heads"],
            action_head=str(
                model.get(
                    "action_head",
                    MODE_CONDITIONED_ACTION_HEAD
                    if common["mode_conditioned_heads"]
                    else FLAT_ACTION_HEAD,
                )
            ),
        )
    if architecture == "hawk_residual":
        return HawkResidualTemporalPolicy(
            base_hidden_size=int(model.get("base_hidden_size", 192)),
            base_num_layers=int(model.get("base_num_layers", 2)),
            adapter_hidden_size=int(model.get("adapter_hidden_size", 128)),
            adapter_num_layers=int(model.get("adapter_num_layers", 2)),
            adapter_recurrent_size=int(
                model.get(
                    "adapter_recurrent_size",
                    math.ceil(4 * int(model.get("adapter_hidden_size", 128)) / 3),
                )
            ),
            adapter_mlp_expansion=int(
                model.get("adapter_mlp_expansion", 2)
            ),
            mode_conditioned_heads=common["mode_conditioned_heads"],
        )
    raise ValueError(f"unsupported temporal architecture: {architecture}")


def policy_model_config(policy: nn.Module) -> dict[str, object]:
    getter = getattr(policy, "model_config", None)
    if not callable(getter):
        raise TypeError("temporal policy must expose model_config()")
    return dict(getter())


def load_temporal_policy_checkpoint(
    path: Path | str,
    *,
    device: torch.device | str = "cpu",
) -> tuple[nn.Module, dict]:
    """Load old MinGRU and new architecture-tagged checkpoints uniformly."""
    checkpoint = Path(path)
    payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if not isinstance(payload, Mapping):
        raise TypeError("temporal checkpoint payload must be a mapping")
    state = payload.get("state_dict", payload)
    if not isinstance(state, Mapping):
        raise TypeError("temporal checkpoint state_dict must be a mapping")
    model = dict(payload.get("model", {}))
    architecture = str(model.get("architecture", "min_gru"))
    if architecture in {"min_gru_residual", "hawk_residual"}:
        model.setdefault(
            "hidden_size", int(model.get("base_hidden_size", 192))
        )
        model.setdefault(
            "num_layers", int(model.get("base_num_layers", 2))
        )
    if "hidden_size" not in model:
        model["hidden_size"] = int(
            state["puffer_policy.encoder.encoder.weight"].shape[0]
        )
    if "num_layers" not in model:
        model["num_layers"] = sum(
            key.startswith("puffer_policy.network.layers.")
            and key.endswith(".weight")
            for key in state
        )
    if "mode_conditioned_heads" not in model:
        model["mode_conditioned_heads"] = any(
            "card_and_pass" in key or ".decoder.scores." in key
            for key in state
        )
    if "action_head" not in model:
        if any(".decoder.scores." in key for key in state):
            model["action_head"] = FACTORIZED_ACTION_HEAD
        elif model["mode_conditioned_heads"]:
            model["action_head"] = MODE_CONDITIONED_ACTION_HEAD
        else:
            model["action_head"] = FLAT_ACTION_HEAD
    model.setdefault("architecture", "min_gru")
    policy = build_temporal_policy(model).to(device)
    policy.load_state_dict(state, strict=True)
    return policy, dict(payload)
