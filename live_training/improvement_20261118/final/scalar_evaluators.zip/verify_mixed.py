import hashlib
import json
from math import factorial, sqrt
from pathlib import Path
from statistics import NormalDist
import sys

import numpy as np

source, target = map(Path, sys.argv[1:])
document = json.loads(source.read_bytes())
assert document["base_seed"] == 1524837801 and document["stride"] == 1_000_000
assert document["games"] == 7_680 and len(document["rosters"]) == 3
reports = []
for index, (cell, peers) in enumerate(zip(document["rosters"], [(1, 1), (1, 2), (2, 1)], strict=True)):
    n = 1 + sum(peers)
    games = factorial(n) // factorial(peers[0]) // factorial(peers[1])
    assert cell["players"] == n and cell["games_per_arm"] == games * 128
    layouts = set(map(tuple, cell["layouts"]))
    assert len(layouts) == games
    for layout in layouts:
        assert len(layout) == n and tuple(layout.count(k) for k in ("focal", "best", "random")) == (1, *peers)
    raw = cell["raw_deals"]
    assert [r["seed"] for r in raw] == list(range(1524837801+index*1_000_000, 1524837801+index*1_000_000+128))
    for arm in ("candidate", "baseline"):
        for field in ("wins", "losses", "draws", "turns"):
            assert sum(r[arm][field] for r in raw) == cell[arm][field]
        assert all(sum(r[arm][k] for k in ("wins", "losses", "draws")) == games for r in raw)
        assert cell[arm]["win_rate"] == cell[arm]["wins"] / (games*128)
    pairs = np.array([(r["candidate"]["wins"]-r["baseline"]["wins"])/games for r in raw])
    se = pairs.std(ddof=1)/sqrt(len(pairs))
    mean = pairs.mean()
    normal = mean + np.array([-1, 1])*NormalDist().inv_cdf(.975)*se
    np.testing.assert_allclose([mean, se, *normal], [cell["delta"], cell["paired_se"], *cell["paired_ci95"]], atol=1e-12)
    rng = np.random.default_rng(2138712+index)
    boot = rng.choice(pairs, (20000, len(pairs)), replace=True).mean(1)
    reports.append({"previous_best_opponents": peers[0], "random_opponents": peers[1],
                    "paired_gain": mean.item(), "normal_ci95": normal.tolist(),
                    "bootstrap_ci95": np.quantile(boot, [.025, .975]).tolist()})
with target.open("x") as handle:
    json.dump({"source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
               "games": document["games"], "resamples": 20000, "rosters": reports}, handle, indent=2)
    handle.write("\n")
