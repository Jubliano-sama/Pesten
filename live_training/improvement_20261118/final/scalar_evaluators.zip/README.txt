Use the same native Python environment as the frozen player. Extract each player archive into its own directory. Pass the directory containing frozen_candidate.json as --root.

Standalone six-cell run
python -I scalar_standalone.py --root /path/to/standalone --workers 7 --chunk-blocks 8 --checkpoint standalone.chunks.jsonl --output standalone.json

Mixed tables with the primary player
python -I mixed_tables.py --root /path/to/primary --freeze-manifest frozen_candidate.json --workers 3 --chunk-deals 4 --output mixed.json

Independent verification of either six-cell run
python -I verify_result.py result.json

Independent verification of the mixed-table run
python -I verify_mixed.py mixed.json mixed_verified.json
